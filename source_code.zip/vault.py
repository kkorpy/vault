#!/usr/bin/env python3
"""

violates discords tos if you get banned oh well :sob:


"""
import base64
import json
import os
import subprocess
import sys
import tempfile
import time
import uuid
import urllib.error
import urllib.request
from dataclasses import dataclass, asdict
from pathlib import Path

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, OSError):
        pass

if getattr(sys, "frozen", False):
    _exe = Path(sys.executable).resolve().parent
    ROOT = _exe
    _mp = getattr(sys, "_MEIPASS", None)
    GAMES = Path(_mp) / "data" / "games.json" if _mp else _exe / "data" / "games.json"
    if not GAMES.exists():
        GAMES = _exe / "data" / "games.json"
else:
    ROOT = Path(__file__).resolve().parent
    GAMES = ROOT.parent / "data" / "games.json"
VAULT = ROOT / "vault.json"

ME = "https://discord.com/api/v9/users/@me?with_analytics_token=true"
SCIENCE = "https://discord.com/api/v9/science"
PROPS_URL = "https://cordapi.dolfi.es/api/v2/properties/windows"
GAMES_CDN = "https://cdn.discordapp.com/detectables/games.json"
BATCH = 50
PAUSE = 1
TOKEN_AGE = 12 * 3600
DEBUG = False

CLIENT_VER = "1.0.9253"
CLIENT_BUILD = 594031
NATIVE_BUILD = 88414
OS_VER = "10.0.26200"
UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) discord/1.0.9253 Chrome/148.0.7778.280 "
    "Electron/42.7.1 Safari/537.36"
)

_FP_PS1 = r'''
param(
  [int]$ProcessId = 0,
  [string]$Path,
  [Parameter(Mandatory = $true)][string]$UserId
)

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public static class CertPubKeyHash {
  const uint X509_ASN_ENCODING = 0x00000001;
  const uint PKCS_7_ASN_ENCODING = 0x00010000;
  const uint CALG_SHA_256 = 0x0000800C;

  [StructLayout(LayoutKind.Sequential)] struct Blob { public uint cbData; public IntPtr pbData; }
  [StructLayout(LayoutKind.Sequential)] struct AlgId { public IntPtr pszObjId; public Blob Parameters; }
  [StructLayout(LayoutKind.Sequential)] struct BitBlob { public uint cbData; public IntPtr pbData; public uint cUnusedBits; }
  [StructLayout(LayoutKind.Sequential)] struct PubKeyInfo { public AlgId Algorithm; public BitBlob PublicKey; }
  [StructLayout(LayoutKind.Sequential)] struct FileTime { public uint Low; public uint High; }
  [StructLayout(LayoutKind.Sequential)]
  struct CertInfo {
    public uint Version; public Blob SerialNumber; public AlgId SignatureAlgorithm; public Blob Issuer;
    public FileTime NotBefore; public FileTime NotAfter; public Blob Subject;
    public PubKeyInfo SubjectPublicKeyInfo; public BitBlob IssuerUniqueId; public BitBlob SubjectUniqueId;
    public uint ExtensionCount; public IntPtr Extensions;
  }
  [StructLayout(LayoutKind.Sequential)]
  struct CertContext {
    public uint EncodingType; public IntPtr Encoded; public uint EncodedSize;
    public IntPtr CertInfo; public IntPtr Store;
  }

  [DllImport("crypt32.dll", SetLastError = true)]
  static extern bool CryptHashPublicKeyInfo(
    IntPtr provider, uint algid, uint flags, uint encoding, ref PubKeyInfo info, byte[] hash, ref uint hashSize);

  public static byte[] Hash(IntPtr certContext) {
    var ctx = Marshal.PtrToStructure<CertContext>(certContext);
    var info = Marshal.PtrToStructure<CertInfo>(ctx.CertInfo);
    var hash = new byte[32];
    uint hashSize = 32;
    if (!CryptHashPublicKeyInfo(IntPtr.Zero, CALG_SHA_256, 0, X509_ASN_ENCODING | PKCS_7_ASN_ENCODING, ref info.SubjectPublicKeyInfo, hash, ref hashSize) || hashSize != 32)
      throw new InvalidOperationException("CryptHashPublicKeyInfo failed");
    return hash;
  }
}
"@

if (!$Path) {
  if (!$ProcessId) { throw "Pass -Path <exe> or -ProcessId <pid>." }
  $Path = (Get-Process -Id $ProcessId).Path
}
if (!$Path) { throw "Could not resolve executable path." }

$fs = [IO.File]::Open($Path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete)
try {
  $fileSize = [UInt64]$fs.Length
  $readSize = [int][Math]::Min($fs.Length, 0x10000)
  $buf = [byte[]]::new($readSize)
  $read = $fs.Read($buf, 0, $readSize)
  if ($read -lt 0x40) { throw "File prefix is too small." }
  if ($read -ne $readSize) { [Array]::Resize([ref]$buf, $read) }
} finally {
  $fs.Dispose()
}

if ([BitConverter]::ToUInt16($buf, 0) -ne 0x5A4D) { throw "Not an MZ executable." }
$pe = [BitConverter]::ToInt32($buf, 0x3C)
if ($pe -lt 0 -or [BitConverter]::ToUInt32($buf, $pe) -ne 0x4550) { throw "Not a PE executable." }

$fh = $pe + 4
$sections = [BitConverter]::ToUInt16($buf, $fh + 2)
$timestamp = [BitConverter]::ToUInt32($buf, $fh + 4)
$optSize = [BitConverter]::ToUInt16($buf, $fh + 16)
$opt = $fh + 20
$isPe32Plus = [BitConverter]::ToUInt16($buf, $opt) -eq 0x20B
if (!$isPe32Plus) { throw "Discord only fingerprints PE32+." }
$sizeOfImage = [BitConverter]::ToUInt32($buf, $opt + 56)

$sectionTable = $opt + $optSize
$sha256 = [Security.Cryptography.SHA256]::Create()
$headerHash = $sha256.ComputeHash([byte[]]$buf[0..($sectionTable - 1)])
$sectionHash = $sha256.ComputeHash([byte[]]$buf[$sectionTable..($sectionTable + $sections * 40 - 1)])

$machineGuid = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Cryptography" -Name MachineGuid).MachineGuid
$machineUserHash = $sha256.ComputeHash([Text.Encoding]::UTF8.GetBytes($machineGuid + $UserId))

$sig = Get-AuthenticodeSignature -LiteralPath $Path
$signed = $sig.Status -eq "Valid" -and $sig.SignerCertificate
if ($signed) {
  $name = $sig.SignerCertificate.GetNameInfo([Security.Cryptography.X509Certificates.X509NameType]::SimpleName, $false)
  $certHash = $sha256.ComputeHash([Text.Encoding]::UTF8.GetBytes($name) + [CertPubKeyHash]::Hash($sig.SignerCertificate.Handle))
} else {
  $certHash = [byte[]]::new(32)
}

$flags = 0
if ($signed) { $flags += 1 }
if ($isPe32Plus) { $flags += 2 }

$out = [byte[]](@(1, [byte]$flags) +
  [BitConverter]::GetBytes($fileSize) +
  [BitConverter]::GetBytes($timestamp) +
  [BitConverter]::GetBytes($sizeOfImage) +
  $headerHash + $machineUserHash + $sectionHash + $certHash)

$key = $sha256.ComputeHash([Text.Encoding]::UTF8.GetBytes($UserId + "https://discord.com/careers"))
for ($i = 1; $i -lt $out.Length; $i++) {
  $out[$i] = $out[$i] -bxor $key[($i - 1) -band 31]
}

[Convert]::ToBase64String($out)
'''


def uid_of(token):
    try:
        head = token.split(".", 1)[0]
        pad = "=" * (-len(head) % 4)
        return base64.b64decode(head + pad).decode("utf-8")
    except Exception:
        return ""


def mk_fingerprint(uid, path="", pid=0):
    if os.name != "nt":
        raise RuntimeError("fingerprint generation is windows-only")
    script = Path(tempfile.gettempdir()) / f"fp_{uuid.uuid4().hex}.ps1"
    script.write_text(_FP_PS1, encoding="utf-8")
    try:
        args = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
                "-File", str(script), "-UserId", uid]
        args += (["-ProcessId", str(pid)] if pid else ["-Path", path])
        result = subprocess.run(args, capture_output=True, text=True, timeout=60)
    finally:
        try:
            script.unlink()
        except OSError:
            pass
    if result.returncode != 0:
        lines = (result.stderr or result.stdout or "").strip().splitlines()
        raise RuntimeError(lines[-1] if lines else "powershell failed")
    out = [line.strip() for line in result.stdout.splitlines() if line.strip()]
    if not out:
        raise RuntimeError("generator produced no output")
    return out[-1]


class Term:
    PURPLE = "\x1b[38;5;141m"
    PURPLE_BRIGHT = "\x1b[95m"
    RED = "\x1b[91m"
    GREEN = "\x1b[92m"
    YELLOW = "\x1b[93m"
    WHITE = "\x1b[97m"
    GREY = "\x1b[90m"
    RESET = "\x1b[0m"
    RULE = "━" * 44

    def __init__(self):
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
        if sys.platform == "win32":
            self._enable_ansi()

    @staticmethod
    def _enable_ansi():
        import ctypes

        kernel32 = ctypes.windll.kernel32
        handle = kernel32.GetStdHandle(-11)
        mode = ctypes.c_uint32()
        if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            kernel32.SetConsoleMode(handle, mode.value | 0x0004)

    def _stamp(self):
        return f"{self.GREY}[{time.strftime('%H:%M:%S')}]"

    def _line(self, glyph, target, detail, color):
        print(f"  {self._stamp()} -> {glyph} {self.WHITE}{target}{self.RESET} "
              f"{self.GREY}·{self.RESET} {color}{detail}{self.RESET}")

    def ok(self, target, detail):
        self._line(f"{self.GREEN}[ok]{self.RESET}", target, detail, self.GREEN)

    def done(self, target, detail):
        self._line(f"{self.GREEN}[done]{self.RESET}", target, detail, self.GREEN)

    def warn(self, target, detail):
        self._line(f"{self.YELLOW}[!]{self.RESET}", target, detail, self.YELLOW)

    def err(self, target, detail):
        self._line(f"{self.RED}[err]{self.RESET}", target, detail, self.RED)

    def info(self, detail):
        print(f"  {self._stamp()} -> {self.PURPLE}{detail}{self.RESET}")

    def rule(self):
        print(f"  {self.PURPLE}{self.RULE}{self.RESET}")

    def clear(self):
        print("\x1b[2J\x1b[3J\x1b[H", end="")

    def banner(self):
        self.clear()
        print()
        print(f"  {self.PURPLE}vault{self.RESET} {self.GREY}·{self.RESET} {self.WHITE}discord badges{self.RESET}")
        print(f"    {self.GREY}discord game/hour adder{self.RESET}")
        print()


@dataclass
class Vault:
    token: str = ""
    cookie: str = ""
    fingerprint: str = ""
    analytics_token: str = ""
    fetched_at: int = 0
    used_games: list = None
    total_games_claimed: int = 0
    total_hours_claimed: float = 0.0

    def __post_init__(self):
        if self.used_games is None:
            self.used_games = []

    @classmethod
    def load(cls):
        if VAULT.exists():
            data = json.loads(VAULT.read_text(encoding="utf-8"))
            st = cls()
            for k, v in data.items():
                if hasattr(st, k):
                    setattr(st, k, v)
            return st
        return cls()

    def save(self):
        VAULT.write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")

    @property
    def is_stale(self):
        return not self.analytics_token or (time.time() - self.fetched_at) > TOKEN_AGE

    @property
    def has_cookie(self):
        return bool(self.cookie.strip())

    @property
    def has_token(self):
        return bool(self.token.strip())


def local_props():
    return {
        "os": "Windows",
        "browser": "Discord Client",
        "release_channel": "stable",
        "client_version": CLIENT_VER,
        "os_version": OS_VER,
        "os_arch": "x64",
        "app_arch": "x64",
        "system_locale": "en-GB",
        "has_client_mods": False,
        "browser_user_agent": UA,
        "browser_version": "42.7.1",
        "os_sdk_version": "26200",
        "client_build_number": CLIENT_BUILD,
        "native_build_number": NATIVE_BUILD,
        "client_event_source": None,
        "client_app_state": "focused",
    }


def super_props(launch_sig, hb_sid):
    try:
        req = urllib.request.Request(PROPS_URL, method="POST", data=b"{}",
                                     headers={"content-type": "application/json", "user-agent": UA})
        with urllib.request.urlopen(req, timeout=10) as response:
            props = json.loads(response.read().decode("utf-8"))["properties"]
    except Exception:
        props = local_props()
    props["client_launch_id"] = str(uuid.uuid4())
    props["launch_signature"] = launch_sig
    props["client_heartbeat_session_id"] = hb_sid
    raw = json.dumps(props, separators=(",", ":")).encode("utf-8")
    return base64.b64encode(raw).decode("ascii")


def fetch_analytics(auth_token, super_props_val):
    req = urllib.request.Request(ME, headers={
        "authorization": auth_token,
        "user-agent": UA,
        "x-super-properties": super_props_val,
    })
    try:
        with urllib.request.urlopen(req, timeout=15) as response:
            data = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"token rejected ({exc.code})") from exc
    token = data.get("analytics_token")
    if not token:
        raise RuntimeError("no analytics_token in response")
    return token


def refresh_token(st, super_props_val):
    if not st.is_stale:
        return
    st.analytics_token = fetch_analytics(st.token, super_props_val)
    st.fetched_at = int(time.time())
    st.save()


@dataclass(frozen=True)
class Ident:
    heartbeat_session = ""
    launch_signature = ""
    super_props = ""

    def __init__(self, heartbeat_session, launch_signature, super_props):
        object.__setattr__(self, "heartbeat_session", heartbeat_session)
        object.__setattr__(self, "launch_signature", launch_signature)
        object.__setattr__(self, "super_props", super_props)

    @classmethod
    def new(cls):
        hb = str(uuid.uuid4())
        sig = str(uuid.uuid4())
        return cls(hb, sig, super_props(sig, hb))


@dataclass(frozen=True)
class Entry:
    id = ""
    name = ""
    exe = ""

    def __init__(self, id, name, exe):
        object.__setattr__(self, "id", id)
        object.__setattr__(self, "name", name)
        object.__setattr__(self, "exe", exe)


def win_exe(game):
    for entry in game.get("executables", []):
        if entry.get("os") == "win32" and entry.get("name"):
            return entry["name"]
    return "game.exe"


def fetch_games():
    request = urllib.request.Request(GAMES_CDN, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(request, timeout=30) as response:
        raw = response.read().decode("utf-8")
    try:
        GAMES.parent.mkdir(parents=True, exist_ok=True)
        GAMES.write_text(raw, encoding="utf-8")
    except OSError:
        pass
    return raw


def parse_games(raw):
    data = json.loads(raw)
    games = []
    seen = set()
    for entry in data:
        gid = str(entry.get("id", ""))
        if not gid.isdigit() or gid in seen:
            continue
        if not any(e.get("os") == "win32" and e.get("name") for e in entry.get("executables", [])):
            continue
        seen.add(gid)
        games.append(Entry(gid, entry.get("name", "Unknown"), win_exe(entry)))
    return games


def load_games():
    raw = ""
    if GAMES.exists():
        raw = GAMES.read_text(encoding="utf-8").strip()
    if raw:
        try:
            games = parse_games(raw)
            if games:
                return games
        except (json.JSONDecodeError, ValueError):
            pass
    try:
        return parse_games(fetch_games())
    except Exception:
        return []


class Poster:
    def __init__(self, st, ident):
        self.st = st
        self.ident = ident
        self._seq = 0

    def next_seq(self):
        self._seq += 1
        return self._seq

    def launch_event(self, game):
        now = int(time.time() * 1000)
        props = {
            "client_track_timestamp": now,
            "client_heartbeat_session_id": self.ident.heartbeat_session,
            "event_sequence_number": self.next_seq(),
            "game": game.name,
            "game_id": game.id,
            "verified": True,
            "elevated": False,
            "is_launcher": False,
            "game_platform": "desktop",
            "detection_method": "verified_game",
            "is_overlay_enabled": False,
            "is_overlay_game_enabled": True,
            "is_overlay_game_source": "OOP_DEFAULT_DATABASE",
            "fullscreen_type": "UNKNOWN",
            "hardware_display_count": 1,
            "overlay_method": "Disabled",
            "activity_status_enabled": True,
            "activity_status_shared_guilds": [],
            "current_user_status": "online",
            "game_detection_enabled": True,
            "executable_path": game.exe,
            "voice_channel_id": None,
            "voice_channel_type": None,
            "voice_channel_bitrate": None,
            "voice_channel_guild_id": None,
            "hidden_by_distributor": False,
            "game_metadata": None,
            "executable_fingerprint": self.st.fingerprint,
            "client_performance_cpu": None,
            "client_performance_memory": None,
            "cpu_core_count": None,
            "accessibility_features": 0,
            "rendered_locale": "en-GB",
            "launch_signature": self.ident.launch_signature,
            "client_rtc_state": None,
            "client_app_state": "focused",
            "client_send_timestamp": now,
        }
        if not self.st.fingerprint:
            del props["executable_fingerprint"]
        return {"type": "launch_game", "properties": props}

    def beat_event(self, game, duration_ms, sid, initial, final, ts=None):
        ts = int(time.time() * 1000) if ts is None else ts
        return {
            "type": "running_game_heartbeat",
            "properties": {
                "client_track_timestamp": ts,
                "client_heartbeat_session_id": self.ident.heartbeat_session,
                "event_sequence_number": self.next_seq(),
                "game_id": game.id,
                "game_name": game.name,
                "game_metadata": None,
                "game_executable": game.exe,
                "game_detection_enabled": True,
                "initial_heartbeat": initial,
                "final_heartbeat": final,
                "game_session_id": sid,
                "duration_tracked_ms": duration_ms,
                "rtc_connection_id": None,
                "media_session_id": None,
                "launch_signature": self.ident.launch_signature,
                "client_app_state": "focused",
                "client_send_timestamp": ts,
            },
        }

    def session_events(self, game, duration_ms):
        sid = str(uuid.uuid4())
        now = int(time.time() * 1000)
        start = now - duration_ms
        if start < 0:
            start = now
        return [
            self.beat_event(game, 0, sid, True, False, start),
            self.launch_event(game),
            self.beat_event(game, duration_ms, sid, False, True, now),
        ]

    def post(self, events):
        payload = {"token": self.st.analytics_token, "events": list(events)}
        body = json.dumps(payload).encode("utf-8")
        headers = {
            "accept": "*/*",
            "accept-language": "en-GB",
            "authorization": self.st.token,
            "content-type": "application/json",
            "cookie": self.st.cookie,
            "origin": "https://discord.com",
            "referer": "https://discord.com/channels/@me",
            "user-agent": UA,
            "x-debug-options": "bugReporterEnabled",
            "x-discord-locale": "en-GB",
            "x-discord-timezone": "Europe/Oslo",
            "x-super-properties": self.ident.super_props,
        }
        if DEBUG:
            print("\n" + "=" * 72)
            print(f"POST {SCIENCE} ({len(payload['events'])} events)")
            print("headers:", json.dumps(headers, indent=2))
            print("body:", json.dumps(payload, indent=2))
            print("=" * 72)
        request = urllib.request.Request(SCIENCE, data=body, method="POST", headers=headers)
        try:
            with urllib.request.urlopen(request, timeout=15) as response:
                return response.status
        except urllib.error.HTTPError as exc:
            return exc.code
        except Exception:
            return 0


def chunks(items, size):
    for start in range(0, len(items), size):
        yield items[start:start + size]


class Pump:
    def __init__(self, poster, term):
        self.poster = poster
        self.term = term

    def run(self, games, build_events):
        total = len(games)
        sent_ok = 0
        for request_no, chunk in enumerate(chunks(games, BATCH), start=1):
            events = []
            for game in chunk:
                events.extend(build_events(game))
            status = self.poster.post(events)
            if status == 204:
                sent_ok += len(chunk)
                self.term.done(f"{request_no}/{total}", f"{len(chunk)} games posted · {sent_ok}/{total} complete")
            elif status in (401, 403):
                self.term.err(f"batch {request_no}",
                              f"[{status}] auth rejected · refresh with a fresh cookie")
                return sent_ok
            else:
                self.term.warn(f"batch {request_no}", f"[{status}]")
            time.sleep(PAUSE)
        return sent_ok


class Tool:
    def __init__(self):
        self.term = Term()
        self.st = Vault.load()
        self.ident = None
        self.poster = None
        self.games = []


    def start(self):
        self.term.banner()
        time.sleep(0.8)
        print()

        C = self.term
        if not self.st.has_token:
            self.ask_token()
        else:
            C.ok("auth", "token loaded")
            time.sleep(0.5)
        if not self.st.has_token:
            C.err("token", "required to run")
            return

        if not self.st.has_cookie:
            self.term.banner()
            self.ask_cookie()
        else:
            C.ok("auth", "cookie loaded")
            time.sleep(0.5)
        if not self.st.has_cookie:
            C.err("cookie", "required to run")
            return

        self.term.banner()
        print()
        C.info("loading games...")
        time.sleep(0.4)
        self.games = load_games()
        if not self.games:
            C.err("games", "couldn't load the game list")
            C.info(f"tried {GAMES} and {GAMES_CDN}")
            C.info("check your connection, or drop a valid games.json at the path above")
            return
        C.ok("games", f"{C.PURPLE}{len(self.games)}{C.WHITE} loaded")
        time.sleep(0.5)

        if not self.st.fingerprint:
            print()
            C.warn("fingerprint", "not set · script may not credit the badges")
            time.sleep(0.5)

        print()
        C.info("validating auth...")
        self.new_ident()
        try:
            refresh_token(self.st, self.ident.super_props)
        except Exception as exc:
            C.err("token", str(exc))
            return
        C.ok("auth", "ready")
        time.sleep(0.5)

        print()
        self.menu()

    def new_ident(self):
        self.ident = Ident.new()
        self.poster = Poster(self.st, self.ident)

    def ask_token(self):
        C = self.term
        self.term.info("paste your discord account token")
        entered = input(f"  {C.GREY}token:{C.RESET} ").strip()
        if entered:
            self.st.token = entered
            self.st.save()
            self.term.ok("token", "saved to vault.json")
            time.sleep(1.5)

    def ask_cookie(self):
        C = self.term
        self.term.info("paste your cf_clearance cookie header")
        entered = input(f"  {C.GREY}cookie:{C.RESET} ").strip()
        if entered:
            self.st.cookie = entered
            self.st.save()
            self.term.ok("cookie", "saved to vault.json")
            time.sleep(1.5)

    def refresh_auth(self):
        self.term.info("update cookie? [y/n]")
        choice = input(f"  {self.term.GREY}›{self.term.RESET} ").strip().lower()
        if choice in ("y", "yes"):
            self.term.info("paste a fresh cookie header")
            entered = input(f"  {self.term.GREY}cookie:{self.term.RESET} ").strip()
            if entered:
                self.st.cookie = entered
                self.term.ok("cookie", "updated")
            else:
                self.term.info("cookie unchanged")

        self.term.info("refreshing analytics token...")
        try:
            self.st.fetched_at = 0
            refresh_token(self.st, self.ident.super_props)
        except Exception as exc:
            self.term.err("auth", str(exc))
            return
        self.new_ident()
        self.st.save()
        self.term.ok("auth", "refreshed")
        time.sleep(1.5)

    def ready(self):
        if not self.st.has_cookie:
            self.term.err("cookie", "not set · use refresh to add one")
            return False
        if self.st.is_stale:
            try:
                refresh_token(self.st, self.ident.super_props)
            except Exception as exc:
                self.term.err("auth", str(exc))
                return False
            self.new_ident()
        return bool(self.st.analytics_token)

    def claim(self):
        if not self.ready():
            return
        C = self.term
        print()
        C.info(f"loaded {C.GREEN}{len(self.games)}{C.WHITE} games available")

        raw_count = input(f"  {C.GREY}how many games? [all]:{C.RESET} ").strip()
        try:
            count = int(raw_count) if raw_count else len(self.games)
        except ValueError:
            C.err("input", "invalid count")
            return
        count = min(count, len(self.games))

        raw_hours = input(f"  {C.GREY}hours per game? [1]:{C.RESET} ").strip()
        try:
            hours = float(raw_hours) if raw_hours else 1.0
        except ValueError:
            C.err("input", "invalid hours")
            return

        selected = self.pick(count)
        if not selected:
            C.err("games", "none selected")
            return

        duration_ms = int(hours * 3600 * 1000)
        total_hours = len(selected) * hours
        print()
        C.info(
            f"claiming {C.PURPLE}{hours:g}h{C.WHITE} on "
            f"{C.PURPLE}{len(selected)}{C.WHITE} games "
            f"{C.GREY}·{C.WHITE} {total_hours:,.0f}h total"
        )
        C.rule()
        ok = Pump(self.poster, self.term).run(
            selected,
            lambda g: self.poster.session_events(g, duration_ms),
        )
        print()
        C.ok("complete", f"{ok}/{len(selected)} games · {ok * hours:,.0f}h claimed")
        self.st.total_games_claimed += ok
        self.st.total_hours_claimed += ok * hours
        self.st.save()

        C.rule()
        input(f"  {C.PURPLE}›{C.RESET} press enter to continue")
        C.rule()

    def pick(self, count):
        available_ids = {g.id for g in self.games}
        unused_ids = [g.id for g in self.games if g.id not in self.st.used_games]
        used_ids = [gid for gid in self.st.used_games if gid in available_ids]

        if len(unused_ids) >= count:
            selected_ids = unused_ids[:count]
        else:
            selected_ids = unused_ids
            if used_ids:
                remaining = count - len(selected_ids)
                rotated = used_ids[remaining:] + used_ids[:remaining]
                selected_ids.extend(rotated[:remaining])

        self.st.used_games = [gid for gid in self.st.used_games if gid not in selected_ids] + selected_ids

        id_map = {g.id: g for g in self.games}
        return [id_map[gid] for gid in selected_ids if gid in id_map]

    def set_fp(self):
        C = self.term
        uid = uid_of(self.st.token)
        if not uid:
            C.err("fingerprint", "no valid token · set one first")
            time.sleep(1.5)
            return
        if os.name != "nt":
            C.err("fingerprint", "windows-only feature")
            time.sleep(1.5)
            return
        C.info("generate an executable_fingerprint tied to this account + machine")
        C.info(f"account: {C.PURPLE}{uid}{C.RESET}")
        C.info("point it at a game's .exe (or a running game's pid)")
        entered = input(f"  {C.GREY}exe path or pid:{C.RESET} ").strip().strip('"')
        if not entered:
            C.info("cancelled")
            time.sleep(1)
            return
        pid = int(entered) if entered.isdigit() else 0
        path = "" if pid else entered
        if path and not Path(path).exists():
            C.err("fingerprint", f"file not found: {path}")
            time.sleep(1.5)
            return
        C.info("generating...")
        try:
            fp = mk_fingerprint(uid, path=path, pid=pid)
        except Exception as exc:
            C.err("fingerprint", str(exc))
            time.sleep(2)
            return
        self.st.fingerprint = fp
        self.st.save()
        C.ok("fingerprint", f"set ({len(fp)} chars) · saved to {VAULT.name}")
        time.sleep(1.5)

    def menu(self):
        C = self.term
        while True:
            C.clear()
            C.banner()
            print()
            C.info(f"loaded {len(self.games)} games")
            C.info(f"claimed {C.PURPLE}{self.st.total_games_claimed}{C.WHITE} games · {C.PURPLE}{self.st.total_hours_claimed:,.0f}h{C.WHITE} total")
            C.rule()
            C.info(f"{C.PURPLE}[1]{C.RESET} · claim games")
            C.info(f"{C.PURPLE}[2]{C.RESET} · refresh auth")
            C.info(f"{C.PURPLE}[3]{C.RESET} · set fingerprint")
            C.info(f"{C.PURPLE}[4]{C.RESET} · exit")
            C.rule()
            choice = input(f"  {C.PURPLE}›{C.RESET} ").strip()
            print()
            if choice == "1":
                self.claim()
            elif choice == "2":
                self.refresh_auth()
            elif choice == "3":
                self.set_fp()
            elif choice in ("4", ""):
                break
            else:
                C.warn("input", "invalid option")


def run():
    try:
        Tool().start()
    except KeyboardInterrupt:
        print()
        Term().warn("exit", "interrupted")


if __name__ == "__main__":
    run()
